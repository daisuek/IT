package com.vti.grabbike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrabbikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
