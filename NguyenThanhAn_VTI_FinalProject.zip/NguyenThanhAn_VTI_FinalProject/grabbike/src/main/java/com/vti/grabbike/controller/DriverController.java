package com.vti.grabbike.controller;


import com.vti.grabbike.model.Driver;
import com.vti.grabbike.repository.DriverRepositoty;
import jakarta.persistence.Entity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/v1/driver")
public class DriverController {
    @Autowired
    DriverRepositoty driverRepositoty;
    @GetMapping("/getdriver")
    List<Driver> getListDriver() {return driverRepositoty.findAll();}
    @GetMapping("/{id}")
    Optional<Driver> getListDriver(@PathVariable Long id) {
        Optional<Driver> foundDriver = driverRepositoty.findById(id);
        return foundDriver;}
    @PostMapping("/insertDriver")
    Driver insert (@RequestBody Driver driver) {return driverRepositoty.save(driver);}


}
