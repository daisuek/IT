package com.vti.grabbike.repository;

import com.vti.grabbike.model.Driver;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DriverRepositoty extends JpaRepository<Driver, Long> {

}
