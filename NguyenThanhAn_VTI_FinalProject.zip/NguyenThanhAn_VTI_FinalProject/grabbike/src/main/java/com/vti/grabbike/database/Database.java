package com.vti.grabbike.database;

import com.vti.grabbike.repository.DriverRepositoty;
import org.springframework.boot.CommandLineRunner;

public class Database {
    CommandLineRunner initDatabase(DriverRepositoty driverRepositoty){
        return new CommandLineRunner() {
            @Override
            public void run(String... args) throws Exception {

            }
        };

    }
}
