package com.vti.grabbike;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrabbikeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrabbikeApplication.class, args);
	}

}
